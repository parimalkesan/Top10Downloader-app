package com.example.top10downloader;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.util.List;

public class FeedAdaptor extends ArrayAdapter {
    private static final String TAG = "FeedAdaptor";
    private final int layoutResource;
    private final LayoutInflater layoutInflator;
    private List<FeedEntry> applications;

    public FeedAdaptor(Context context, int resource, List<FeedEntry> applications) {
        super(context, resource);
        this.layoutResource = resource;
        this.layoutInflator = LayoutInflater.from(context);
        this.applications = applications;

    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @androidx.annotation.NonNull
    @Override
    public View getView(int position, @androidx.annotation.Nullable View convertView, @androidx.annotation.NonNull ViewGroup parent) {
        return super.getView(position, convertView, parent);
    }
}
